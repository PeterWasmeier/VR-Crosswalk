#include <math.h>
#include <Pid.h>

long DcMotorPID::compute(int32_t setpoint, int32_t feedback) {
  time_t curTime;
  double sampleTime;
  int32_t curError;
  float pTerm;
  float iTerm;
  float dTerm;

  curTime = micros();
  sampleTime = curTime - sampleLastTime;
  if(sampleTime < 0)
    sampleTime += 0xFFFFFFFF; // in case of overflow 

  // Serial.print(sampleTime);
  // Serial.print(" ");

  sampleTime /= 1000000.0; // time in second

  curError = setpoint - feedback;

  /* proportional term computation */
  pTerm = kp * curError;

  /* integral term computation */
  if(ki == 0.0)
    integral = 0;
  else {
    int32_t lastIntegral;

    iTerm = ki * curError * sampleTime;

    if(iTerm > 0)
      iTerm  = ceil(iTerm);
    else
      iTerm  = floor(iTerm);

    /* Check iTerm bound */
    if(iTermMax != 0 &&(iTerm > iTermMax))
      iTerm = iTermMax;

    if(iTermMin != 0 &&(iTerm < iTermMin))
      iTerm = iTermMin;

    lastIntegral = integral;
    integral += iTerm;

    /* Check  integral overflow  */
    if(integral > 0 && iTerm < 0 && lastIntegral < 0)
      integral = INT32_MIN;
    else if(integral < 0 && iTerm > 0 && lastIntegral > 0)
      integral = INT32_MAX;

    /* Check integral bound */
    if(integralMax != 0 &&(integral > integralMax))
      integral = integralMax;

    if(integralMin != 0 &&(integral < integralMin))
      integral = integralMin;

    lastIntegral = integral;
    integral += iTerm;
  }

  /* differential term computation */
  dTerm = kd * (curError - lastError) / sampleTime;

  lastError = curError;
  sampleLastTime = curTime;

  return round(pTerm + integral + dTerm);
}

DcMotorPID::DcMotorPID(uint8_t sid, uint8_t port): ExpansionDCMotor(sid, port) {
  kp = 0;
  ki = 0;
  kd = 0;
  type = PID_NONE;
  scale = 1;
  integral = 0;
  lastError = 0;
  integralMax = 0;
  integralMin = 0;
  iTermMax = 0;
  iTermMin = 0;
  pwmPeriod = 10000;
  sampleLastTime = micros();

  lastDir = 0;
  lastWidth = 0;
}

void DcMotorPID::setGain(float pGain, float iGain, float dGain) {
  kp = pGain;
  ki = iGain;
  kd = dGain;
}

void DcMotorPID::setPeriod(long period) {
  pwmPeriod = period;
  ExpansionDCMotor::setPeriod(pwmPeriod);
}

void DcMotorPID::setScaleFactor(float scaleFactor) {scale = scaleFactor; }

void DcMotorPID::setIntegralLimit(long min, long max) {
  integralMin = min;
  integralMax = max;
}

void DcMotorPID::setIntegralTermLimit(long min, long max) {
  iTermMin = min;
  iTermMax = max;
}

long DcMotorPID::getSpeed(void) {
  long encPeriod;

  encPeriod = getEncoderPeriod();

  if(!encPeriod)
    return 0;
  else
    return (1000000 / encPeriod);
}

float DcMotorPID::getKp(void) {return kp; }
float DcMotorPID::getKi(void) {return ki; }
float DcMotorPID::getKd(void) {return kd; }

void DcMotorPID::begin(uint8_t pidType) {
  type = pidType;
  sampleLastTime = micros();

  ExpansionDCMotor::setPeriod(pwmPeriod);
}

void DcMotorPID::beginTune(void) {
  tuneState = PID_TUNE_STATE_START;
  ExpansionDCMotor::setPeriod(pwmPeriod);
}

bool DcMotorPID::loopTune(void) {
  long curFeedback;

  if(type != PID_POSITION && type != PID_SPEED) {
     Serial.println(F("Please call begin() before calling beginTune() function"));
     return false;
  }

  switch(tuneState) {
    case PID_TUNE_STATE_START:
      if(type == PID_POSITION) {
        tuneBaseInput = 0;
        tuneStep = pwmPeriod * 3 / 10; /* 30% */
      } else if(type == PID_SPEED) {
        tuneBaseInput = pwmPeriod * 4 / 10; /* 40% */
        tuneStep = pwmPeriod / 10; /* 10% */
      }
      else
        return false;

      tuneInput = tuneBaseInput;
      setWidth(tuneInput);
      lastTuneInput = tuneInput;

      tuneWaitTime = micros() + 500000 ; // 500000 us
      tuneState = PID_TUNE_STATE_WAIT;
      return false;

    case PID_TUNE_STATE_WAIT:
      /* wait to let process settle to a steady state */
      if(tuneWaitTime > micros())
        return false;

      if(type == PID_POSITION)
        tuneSetpoint = getEncoderPosition();
      else if(type == PID_SPEED)
        tuneSetpoint = getSpeed();
      else
        return false;

      tuneLastFeedback = tuneSetpoint;

      tuneDirChange = 0;
      tuneMaxSum = 0;
      tuneMinSum = 0;
      tuneMaxCount = 0;
      tuneMinCount = 0;
      tuneNoiseband = 4;
      tuneStartTime = 0;
      tuneEndTime = 0;
      tuneInput = tuneBaseInput + tuneStep;
      tuneState = PID_TUNE_STATE_LOOP;
      return false;

    case PID_TUNE_STATE_LOOP:

      if(type == PID_POSITION)
        curFeedback = getEncoderPosition();
      else if(type == PID_SPEED)
        curFeedback = getSpeed();
      else
        return false;

      if(curFeedback > tuneLastFeedback) {
        if(tuneDirChange == -1) {
          if(tuneMaxCount >= 2) { // Ignore the first maximum
            tuneMinSum += tuneLastFeedback;
            tuneMinCount++;
          }
        }

        tuneDirChange = 1;
      }
      else
      if(curFeedback < tuneLastFeedback) {
        if(tuneDirChange == 1) {
          if(tuneMaxCount >= 1)
            tuneMaxSum += tuneLastFeedback;

          tuneMaxCount++;

          if(tuneMaxCount == 2)
            tuneStartTime = micros();
          else if(tuneMaxCount == 12) {
            tuneEndTime = micros();
            tuneState = PID_TUNE_STATE_END;
            return false;
          }
        }

        tuneDirChange = -1;
      }

      if(tuneSetpoint > (curFeedback + tuneNoiseband))
        tuneInput = tuneBaseInput + tuneStep;
      else if(tuneSetpoint < (curFeedback - tuneNoiseband))
        tuneInput = tuneBaseInput - tuneStep;

      if(lastTuneInput != tuneInput) {
        if(tuneInput >= 0) {
          setDirection(1);
          setWidth(tuneInput);
        } else {
          setDirection(-1);
          setWidth(-1 * tuneInput);
        }

        lastTuneInput = tuneInput;
      }

      tuneLastFeedback = curFeedback;
      return false;

    case PID_TUNE_STATE_END:
      /*stop motor*/
      setWidth(0);

      /*evaluate ultimate gain using autotune formulas*/
      float averageMax;
      float averageMin;
      float a;
      double Tu;
      float Ku;

      averageMax = ((float)tuneMaxSum) / (tuneMaxCount - 1);
      averageMin = ((float)tuneMinSum) / tuneMinCount;
      a = (averageMax - averageMin) / 2.0;

      Tu = tuneEndTime - tuneStartTime;
      if(Tu < 0)
        Tu += 0xFFFFFFFF; // in case of overflow 

      Tu = Tu / 10.0 / 1000000; //average of 10 cycles in second
      Ku = 4 * tuneStep / (M_PI * a);

      /*
      //classic PID according to Ziegler–Nichols method
      kp = 0.6 * Ku;
      ki = 2 / Tu ;
      kd = Tu / 8;
      */

      /*no overshoot according to Ziegler–Nichols method*/
      kp = 0.2 * Ku;
      ki = 2.0 / Tu;
      kd = Tu / 3.0;

      tuneState = PID_TUNE_STATE_IDLE;

      return true;

    default:
      return false;
  }
}

long DcMotorPID::loop(int32_t setpoint) {
  long feedback;
  long pwmWidth;

  if(type == PID_POSITION) {
    int8_t dir;

    feedback = getEncoderPosition();
    pwmWidth = compute(setpoint, feedback) / scale;

    if(pwmWidth >= 0)
      dir = 1;
    else
      dir = -1;

    pwmWidth *= dir;

    if(setpoint == feedback) {
      integral = 0;
      pwmWidth = 0;
    }

    if(lastDir != dir) {
      setDirection(dir);
      lastDir = dir;
    }

    if(lastWidth != pwmWidth) {
      setWidth(pwmWidth);
      lastWidth = pwmWidth;
    }
  } else if(type == PID_SPEED) {
    feedback = getSpeed();
    pwmWidth = compute(setpoint, feedback) / scale;

    if(setpoint == feedback)
      return feedback;

    if(pwmWidth < 0)
      pwmWidth = 0;

    if(lastWidth != pwmWidth) {
      setWidth(pwmWidth);
      lastWidth = pwmWidth;
    }
  }

  return feedback;
}