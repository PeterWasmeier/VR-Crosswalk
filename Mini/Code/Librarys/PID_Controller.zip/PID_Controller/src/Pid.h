#ifndef Pid_h
#define Pid_h

typedef unsigned long time_t;

#include <Arduino.h>
#include <PhpocExpansion.h>

#define PID_NONE    0
#define PID_POSITION  1
#define PID_SPEED    2

#define INT32_MAX (long)0x7fffffff
#define INT32_MIN (long)0x80000000

/* PID tuning state machine */
#define PID_TUNE_STATE_IDLE   0
#define PID_TUNE_STATE_START  1
#define PID_TUNE_STATE_WAIT   2
#define PID_TUNE_STATE_LOOP   3
#define PID_TUNE_STATE_END    4

class DcMotorPID : public ExpansionDCMotor
{
  private:
    float kp;
    float ki;
    float kd;
    uint8_t type; /* postion or speed */
    int16_t scale;
    int32_t integral;
    int32_t lastError;
    int32_t integralMax;
    int32_t integralMin;
    int32_t iTermMax;
    int32_t iTermMin;
    int32_t pwmPeriod;
    time_t sampleLastTime;
    int8_t lastDir;
    int32_t lastWidth;

    /* tuning parameter */
    uint8_t tuneState;
    int16_t tuneInput;
    int16_t lastTuneInput;
    uint16_t tuneBaseInput;
    uint16_t tuneStep;
    int32_t tuneSetpoint;
    int32_t tuneLastFeedback;
    int8_t tuneDirChange; //0: initial, 1: go up, -1 go down
    int32_t tuneMaxSum;
    int32_t tuneMinSum;
    uint8_t tuneMaxCount;
    uint8_t tuneMinCount;
    uint8_t tuneNoiseband;
    time_t tuneStartTime;
    time_t tuneEndTime;
    time_t tuneWaitTime;

    long compute(long setpoint, long feedback);

  public:
    DcMotorPID(uint8_t sid, uint8_t port);
    void setGain(float pGain, float iGain, float dGain);
    void setPeriod(long period);
    void setScaleFactor(float scaleFactor);
    void setIntegralLimit(long min, long max);
    void setIntegralTermLimit(long min, long max);
    long getSpeed(void);
    float getKp(void);
    float getKi(void);
    float getKd(void);

    void begin(uint8_t pidType);
    void beginTune(void);
    bool loopTune(void);
    long loop(long setpoint);
};

#endif